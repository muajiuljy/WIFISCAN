//include the function prototypes for screen manipulation
enum COLOR{BLACK=30, RED, GREEN ,YELLOW, BLUE, MAGENTA, CYAN, WHITE};
#define UNICODE
#define BAR "\u258A"   //unicode for a bar
//FUNCTION PROTOTYPES
void setFGcolor(int fg);
void resetColors(void);
void gotoXY(int row, int col);
void clearScreen(void);
void displayBar(double rms, int col);


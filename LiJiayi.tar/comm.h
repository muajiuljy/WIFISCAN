//in this header we define some necessary constants for CURL communication

#define COMM

#define URL "http://www.cc.puv.fi/~e1601126/php/sound.php"

void send_data_curl(double []);
